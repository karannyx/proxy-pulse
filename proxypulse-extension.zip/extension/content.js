// Website ko batana ki kaunsa student synced hai
chrome.storage.local.get(["syncedEnrollment"], (res) => {
  if (res.syncedEnrollment) {
    window.localStorage.setItem("proxypulse_enrollment", res.syncedEnrollment);
  }
});

// Website par "Sync from AMS" dabane par AMS portal kholna
window.addEventListener("message", (event) => {
  if (event.data && event.data.type === "START_AMS_SYNC") {
    window.open("https://ams.mitsgwalior.in/student/dashboard", "_blank");
  }
});