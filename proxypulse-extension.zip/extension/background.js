const SUPABASE_URL = "https://isybjtdokjltlkyuinru.supabase.co";
const SUPABASE_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImlzeWJqdGRva2psdGxreXVpbnJ1Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTUyOTQyMzIsImV4cCI6MjExMDg3MDIzMn0.f7yukspxleLmYvMebutdiMzt2yLTKLug2_7zbBAvhQw";

let lastSyncedToken = "";

chrome.webRequest.onBeforeSendHeaders.addListener(
  (details) => {
    const authHeader = details.requestHeaders.find(
      (h) => h.name.toLowerCase() === "authorization"
    );
    if (authHeader && authHeader.value.startsWith("Bearer ")) {
      const token = authHeader.value;
      if (token !== lastSyncedToken) {
        lastSyncedToken = token;
        syncAttendanceToSupabase(token);
      }
    }
  },
  { urls: ["https://ams.mitsgwalior.in/api/api/v1/studentsite/dashboard*"] },
  ["requestHeaders"]
);

async function syncAttendanceToSupabase(bearerToken) {
  try {
    const amsRes = await fetch("https://ams.mitsgwalior.in/api/api/v1/studentsite/dashboard", {
      headers: { Authorization: bearerToken }
    });
    const data = await amsRes.json();
    if (!data.student) return;

    const headers = {
      "Content-Type": "application/json",
      apikey: SUPABASE_KEY,
      Authorization: `Bearer ${SUPABASE_KEY}`,
      Prefer: "resolution=merge-duplicates,return=representation"
    };

    const studentPayload = {
      ams_student_id: data.student.id,
      enrollment_no: data.student.enrollment || `ID_${data.student.id}`,
      full_name: data.student.name,
      email: data.student.email,
      ams_bearer_token: bearerToken,
      overall_percentage: data.statistics.overall_percentage,
      total_classes: data.statistics.total_classes,
      present_classes: data.statistics.present_classes,
      last_synced_at: new Date().toISOString()
    };

    const stRes = await fetch(`${SUPABASE_URL}/rest/v1/students?on_conflict=ams_student_id`, {
      method: "POST",
      headers,
      body: JSON.stringify(studentPayload)
    });
    const stData = await stRes.json();

    if (!Array.isArray(stData) || stData.length === 0) {
      console.error("Supabase Student Error: " + JSON.stringify(stData));
      return;
    }
    const savedStudent = stData[0];

    const coursesPayload = data.courses.map((c) => ({
      student_id: savedStudent.id,
      course_id: c.course_id,
      course_code: c.course_code.trim(),
      course_name: c.course_name,
      course_type: c.course_type,
      faculty_name: c.faculty_name,
      total_classes: c.total_classes,
      present_classes: c.present_classes,
      attendance_percentage: c.attendance_percentage,
      updated_at: new Date().toISOString()
    }));

    await fetch(`${SUPABASE_URL}/rest/v1/courses?on_conflict=student_id,course_id`, {
      method: "POST",
      headers,
      body: JSON.stringify(coursesPayload)
    });

    const logsPayload = data.attendance_records.map((r) => ({
      student_id: savedStudent.id,
      ams_record_id: r.id,
      course_code: r.course_code.trim(),
      course_name: r.course_name,
      class_date: r.date,
      start_time: r.start_time,
      end_time: r.end_time,
      is_present: r.is_present
    }));

    await fetch(`${SUPABASE_URL}/rest/v1/attendance_logs?on_conflict=student_id,ams_record_id`, {
      method: "POST",
      headers,
      body: JSON.stringify(logsPayload)
    });

    chrome.storage.local.set({ syncedEnrollment: studentPayload.enrollment_no });
    console.log("ProxyPulse: Sync Complete!", studentPayload.enrollment_no);
  } catch (err) {
    console.error("ProxyPulse Sync Error:", err);
  }
}